var Masonry = require('masonry-layout');
var Packery = require('packery');
//var Isotope = require('isotope-layout');
var imagesLoaded = require('imagesloaded');

document.addEventListener('DOMContentLoaded', event => {
  imagesLoaded('#grid-wrapper', ()=>{
    var isotope = new Isotope( '#grid-wrapper', {
      // options...
      itemSelector: '.card',
      stagger: '0.02s',
      masonry: {
        gutter: 5
      }
    });
    isotope.on( "masonry.wastedspace", (event, arrayOfWastedAreas)=>{
      console.log('event', event);
      console.log('areas', arrayOfWastedAreas);
    } );
    /* 
    */
  })
})
